const Sequelize = require('sequelize');
const config = require('./../config')


module.exports = async () => {
    const sequelize = new Sequelize(config.DATABASE_NAME, config.DATABASE_USERNAME, config.DATABASE_PASSWORD, {
        host: config.DATABASE_HOST,
        dialect: 'mysql',

        pool: {
            max: 5,
            min: 0,
            idle: 10000
        },
    });
    
    try {
        await sequelize.authenticate();
        console.log('Connection has been established successfully.');

        const dbModel = ['test'] // db name goes here
        for(let model of dbModel)
        {
            require('../controller/' + model + '/model')(sequelize)
        }
        
        
        

        // Excute Database relation
        const models = Object.keys(global.models)
        models.map(async (el) => await global.models[el].associate())
    
        // Database migration
        if(JSON.parse(config.DB_MIGRATION)) {
            models.map(async (el) => await global.models[el].sync({alter: true}))
        }

    } catch (error) {
        console.error('Unable to connect to the database:', error);
    }
}