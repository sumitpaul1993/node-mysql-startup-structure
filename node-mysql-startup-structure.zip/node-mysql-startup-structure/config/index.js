const env = require('dotenv')
const config = {}

// Environment Variables
env.config()


config.PORT = process.env.PORT
config.DATABASE_HOST = process.env.DATABASE_HOST
config.DATABASE_USERNAME = process.env.DATABASE_USERNAME
config.DATABASE_PASSWORD = process.env.DATABASE_PASSWORD
config.DATABASE_NAME = process.env.DATABASE_NAME
config.DB_MIGRATION = process.env.DB_MIGRATION
config.BASE_URL = process.env.BASE_URL
config.SECRET_KEY = process.env.SECRET_KEY


module.exports = config