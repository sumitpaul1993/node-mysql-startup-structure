const covidController = require('./route')

function initCovid(app) {
  app.use('/covid', covidController)
}

module.exports = initCovid