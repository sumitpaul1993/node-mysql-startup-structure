const { DataTypes } = require('sequelize');

module.exports = async (sequelize) => {

    const Covid = sequelize.define('Covid', {
        // Model attributes are defined here
        total: {
            type: DataTypes.INTEGER,
            allowNull: false
            // allowNull defaults to true
        },
        recovery: {
            type: DataTypes.INTEGER,
            allowNull: false
            // allowNull defaults to true
        },
        dead: {
            type: DataTypes.INTEGER,
            allowNull: false
            // allowNull defaults to true
        },
        status: {
            type: DataTypes.ENUM,
            values: ['active', 'inactive'],
            defaultValue: 'active'
        },
        report_on: {
            type: DataTypes.DATEONLY,
            
        }
    }, {
        // Other model options go here
    });

    Covid.associate = () => {
        Covid.belongsTo(global.models.State, {
            foreignKey: 'state_id'
        })
        Covid.belongsTo(global.models.District, {
            foreignKey: 'district_id'
        })
    }

    // await Covid.sync({alter: true})
    global.models['Covid'] = Covid;
}

// module.exports = User