const express = require('express')
const router = express.Router()
const models = global.models;
const { Op } = require('sequelize');
const url = require('url');
const moment = require('moment')

router.get('/', async (req, res) => {
    try {
        // await models.Covid.create({
        //     total: 10000, 
        //     recovery : 8000,
        //     dead:1,
        //     state_id: 2,
        //     district_id : 3
        // })
    } catch (e) {
        console.log(e);
    }
})

router.get('/get-report', async (req, res) => {
    const queryObject = url.parse(req.url, true).query;
    // res.send('covid')
    let where={}

    try {
        if(queryObject.state)
        {
            where.state_id = queryObject.state
        }

        if(queryObject.district)
        {
            where.district_id = queryObject.district
        }

        if(queryObject.date)
        {
            where.report_on =  await moment(queryObject.date).format('YYYY-MM-DD')
        }
        

        const report = await models.Covid.findAll({
            include: [models.State, models.District],
            where : where
        })
        res.status(200).send({
            error: false,
            data: report.length ? report : null
        })
    } catch (e) {
        console.log(e);
        res.status(400).send({
            error: false,
            msg: "something wrong"
        })
    }
})

module.exports = router