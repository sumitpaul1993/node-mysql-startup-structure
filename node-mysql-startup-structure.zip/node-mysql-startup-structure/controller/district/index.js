const distController = require('./route')

function initDist(app) {
  app.use('/district', distController)
}

module.exports = initDist