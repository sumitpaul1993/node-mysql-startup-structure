const { DataTypes } = require('sequelize');

module.exports = async (sequelize) => {

  const District = sequelize.define('District', {
    // Model attributes are defined here
    district_name: {
      type: DataTypes.STRING,
      allowNull: false
      // allowNull defaults to true
    },
    status: {
      type: DataTypes.ENUM,
      values: ['active', 'inactive'],
      defaultValue: 'active'
    }
  }, {
    // Other model options go here
  });

  District.associate = () => {
    District.belongsTo(global.models.State, {
        foreignKey: 'state_id'
      })
  }

  // await District.sync({alter: true})
  global.models['District'] = District;
}

// module.exports = User