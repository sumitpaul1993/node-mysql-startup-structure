const express = require('express')
const router = express.Router()
const models = global.models;


router.get('/',  async (req, res) => {
    res.send('dist')
//    try {
//         await models.District.create({
//             district_name : "test",
//             state_id : 2 
//         })
//     } catch (e) {
//         console.log(e);
//     }
})

module.exports = router