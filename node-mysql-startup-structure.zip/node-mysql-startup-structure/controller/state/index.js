const stateController = require('./route')

function initState(app) {
  app.use('/state', stateController)
}

module.exports = initState