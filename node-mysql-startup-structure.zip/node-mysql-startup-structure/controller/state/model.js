const { DataTypes } = require('sequelize');

module.exports = async (sequelize) => {

  const State = sequelize.define('State', {
    // Model attributes are defined here
    state_name: {
      type: DataTypes.STRING,
      allowNull: false
      // allowNull defaults to true
    },
    country_id: {
        type : DataTypes.INTEGER,
        allowNull: false
    },
    status: {
      type: DataTypes.ENUM,
      values: ['active', 'inactive'],
      defaultValue: 'active'
    }
  }, {
    // Other model options go here
  });

  State.associate = () => {
    
  }

  // await State.sync({alter: true})
  global.models['State'] = State;
}

// module.exports = User