const express = require('express')
const router = express.Router()
const models = global.models;


router.get('/',  async (req, res) => {
    res.send('state')
    // try {
    //     await models.State.create({
    //         state_name : "bihar",
    //         country_id : 1 // demo country id
    //     })
    // } catch (e) {
    //     console.log(e);
    // }
})

module.exports = router