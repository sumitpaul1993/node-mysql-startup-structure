const testController = require('./route')

function initTest(app) {
  app.use('/test', testController)
}

module.exports = initTest