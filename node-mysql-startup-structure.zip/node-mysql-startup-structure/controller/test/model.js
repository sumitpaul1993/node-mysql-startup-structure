const { DataTypes } = require('sequelize');

module.exports = async (sequelize) => {

    const Test = sequelize.define('Test', {
        // Model attributes are defined here
        Test_name: {
            type: DataTypes.STRING,
            allowNull: false
            // allowNull defaults to true
        },
    }, {
        // Other model options go here
    });

    Test.associate = () => {
        // Test.belongsTo(global.models.State, {
        //     foreignKey: 'state_id'
        // })
    }

    // await Test.sync({alter: true})
    global.models['Test'] = Test;
}

// module.exports = User