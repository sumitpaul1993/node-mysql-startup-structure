const express = require('express')
const router = express.Router()
const models = global.models;


router.get('/',  async (req, res) => {
    res.send('test')
})

module.exports = router